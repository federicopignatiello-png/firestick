package com.firepad.app;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothHidDevice;
import android.bluetooth.BluetoothHidDeviceAppSdpSettings;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.Executor;

public class MainActivity extends Activity {
    // Standard relative mouse: Report ID 1, 3 buttons, X/Y delta and wheel (-127..127).
    private static final byte[] MOUSE_DESCRIPTOR = new byte[] {
        0x05,0x01, 0x09,0x02, (byte)0xA1,0x01, (byte)0x85,0x01,
        0x09,0x01, (byte)0xA1,0x00, 0x05,0x09, 0x19,0x01, 0x29,0x03,
        0x15,0x00, 0x25,0x01, (byte)0x95,0x03, 0x75,0x01, (byte)0x81,0x02,
        (byte)0x95,0x01, 0x75,0x05, (byte)0x81,0x03,
        0x05,0x01, 0x09,0x30, 0x09,0x31, 0x09,0x38,
        0x15,(byte)0x81, 0x25,0x7F, 0x75,0x08, (byte)0x95,0x03,
        (byte)0x81,0x06, (byte)0xC0, (byte)0xC0
    };
    private final int ink = Color.rgb(24,27,32), sage = Color.rgb(40,125,105);
    private BluetoothAdapter adapter;
    private BluetoothHidDevice hid;
    private BluetoothDevice target;
    private boolean registered = false, connected = false;
    private TextView status, selected;
    private LinearLayout devices;
    private View pad;
    private float prevX, prevY, remainderX, remainderY;
    private long downAt; private float downX, downY; private boolean moved;
    private final Executor callbackExecutor = Runnable::run;
    private final BluetoothHidDevice.Callback callback = new BluetoothHidDevice.Callback() {
        @Override public void onAppStatusChanged(BluetoothDevice pluggedDevice, boolean isRegistered) {
            registered = isRegistered;
            ui(isRegistered ? "Mouse HID pronto. Associa la Fire Stick e selezionala." : "Registrazione HID non disponibile su questo telefono.");
        }
        @Override public void onConnectionStateChanged(BluetoothDevice device, int state) {
            if (target != null && target.equals(device)) {
                connected = state == BluetoothProfile.STATE_CONNECTED;
                ui(connected ? "Connesso! Prova il trackpad in Brave." : "Non connesso. Seleziona la Fire Stick per riprovare.");
            }
        }
    };
    private void ui(String message) { runOnUiThread(() -> { if(status != null) status.setText(message); }); }
    @Override public void onCreate(Bundle b) { super.onCreate(b); buildUi();
        BluetoothManager manager = getSystemService(BluetoothManager.class);
        adapter = manager == null ? null : manager.getAdapter();
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 10);
        } else setupBluetooth();
    }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if(r == 10 && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) setupBluetooth();
        else ui("Permesso Bluetooth necessario. Abilitalo nelle impostazioni dell'app.");
    }
    private boolean permission() { return Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED; }
    @SuppressWarnings("MissingPermission") private void setupBluetooth() {
        if (adapter == null) { ui("Questo dispositivo non ha Bluetooth."); return; }
        if (!adapter.isEnabled()) { ui("Attiva il Bluetooth e poi premi Riprova."); return; }
        ui("Inizializzazione profilo mouse HID...");
        boolean requested = adapter.getProfileProxy(this, new BluetoothProfile.ServiceListener() {
            @Override public void onServiceConnected(int profile, BluetoothProfile proxy) {
                if(profile != BluetoothProfile.HID_DEVICE) return;
                hid = (BluetoothHidDevice) proxy;
                BluetoothHidDeviceAppSdpSettings sdp = new BluetoothHidDeviceAppSdpSettings(
                    "FirePad Mouse", "Trackpad Android per Fire TV", "FirePad", BluetoothHidDevice.SUBCLASS1_MOUSE, MOUSE_DESCRIPTOR);
                boolean ok = hid.registerApp(sdp, null, null, callbackExecutor, callback);
                if(!ok) ui("Impossibile registrare il profilo HID su questo telefono.");
                refreshDevices();
            }
            @Override public void onServiceDisconnected(int profile) { hid = null; registered = false; connected = false; ui("Servizio Bluetooth scollegato."); }
        }, BluetoothProfile.HID_DEVICE);
        if(!requested) ui("Il telefono non espone il profilo Bluetooth HID Device.");
    }
    @SuppressWarnings("MissingPermission") private void refreshDevices() {
        if (!permission() || adapter == null) return;
        Set<BluetoothDevice> bonded = adapter.getBondedDevices();
        runOnUiThread(() -> {
            devices.removeAllViews();
            if(bonded.isEmpty()) { addHint(devices,"Nessun dispositivo associato. Associa prima la Fire Stick dalle impostazioni Bluetooth."); return; }
            for(BluetoothDevice device : bonded) {
                String name = device.getName() == null ? "Dispositivo sconosciuto" : device.getName();
                Button btn = button(name + "  ·  " + device.getAddress());
                btn.setOnClickListener(v -> connect(device)); devices.addView(btn);
            }
        });
    }
    @SuppressWarnings("MissingPermission") private void connect(BluetoothDevice device) {
        if(hid == null || !registered || !permission()) { ui("Il profilo HID non è ancora pronto."); return; }
        target = device; connected = false;
        selected.setText("Selezionato: " + device.getName());
        ui("Connessione a " + device.getName() + "...");
        if(!hid.connect(device)) ui("Connessione rifiutata. Controlla l'associazione sulla Fire Stick.");
    }
    @SuppressWarnings("MissingPermission") private void report(int buttons, int dx, int dy, int wheel) {
        if(!connected || hid == null || target == null || !permission()) return;
        hid.sendReport(target, 1, new byte[]{(byte)buttons,(byte)dx,(byte)dy,(byte)wheel});
    }
    private void motion(float dx, float dy) {
        remainderX += dx * 1.5f; remainderY += dy * 1.5f;
        int ix = (int)remainderX, iy = (int)remainderY;
        remainderX -= ix; remainderY -= iy;
        // Preserve larger swipes without wrapping 8-bit signed reports.
        while(ix != 0 || iy != 0) {
            int x = Math.max(-127,Math.min(127,ix)); int y = Math.max(-127,Math.min(127,iy));
            report(0,x,y,0); ix -= x; iy -= y;
        }
    }
    private void click(int button) { report(button,0,0,0); report(0,0,0,0); }
    private void wheel(int amount) { report(0,0,0,amount); }
    private GradientDrawable bg(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d; }
    private TextView text(String content, int size, boolean bold) { TextView t = new TextView(this); t.setText(content); t.setTextColor(ink); t.setTextSize(size); if(bold)t.setTypeface(null, Typeface.BOLD); t.setPadding(0,9,0,9); return t; }
    private Button button(String label) { Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextColor(ink); return b; }
    private void addHint(LinearLayout layout, String message) {layout.addView(text(message,13,false));}
    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(Color.rgb(247,248,246));
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,34,28,28); scroll.addView(root); setContentView(scroll);
        root.addView(text("FirePad / 01",29,true)); root.addView(text("Trasforma il telefono in un mouse Bluetooth per Fire TV",14,false));
        status = text("In attesa del Bluetooth...",14,true); status.setTextColor(sage); root.addView(status);
        selected = text("Nessuna Fire Stick selezionata",13,false); root.addView(selected);
        Button settings = button("Apri impostazioni Bluetooth"); settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS))); root.addView(settings);
        Button refresh = button("Riprova / aggiorna dispositivi"); refresh.setOnClickListener(v -> { if(hid == null) setupBluetooth(); else refreshDevices(); }); root.addView(refresh);
        root.addView(text("DISPOSITIVI ASSOCIATI",12,true));
        devices = new LinearLayout(this); devices.setOrientation(LinearLayout.VERTICAL); root.addView(devices);
        root.addView(text("TRACKPAD",12,true));
        pad = new View(this); pad.setBackground(bg(Color.rgb(225,233,230),28)); root.addView(pad,new LinearLayout.LayoutParams(-1,390));
        pad.setOnTouchListener((v,event) -> {
            int action = event.getActionMasked();
            if(action == MotionEvent.ACTION_DOWN) { prevX=downX=event.getX(); prevY=downY=event.getY(); downAt=System.currentTimeMillis(); moved=false; return true; }
            if(action == MotionEvent.ACTION_MOVE) {
                float x=event.getX(), y=event.getY();
                if(Math.hypot(x-downX,y-downY)>14)moved=true;
                if(event.getPointerCount() >= 2) wheel(Math.max(-12,Math.min(12,(int)((prevY-y)/9))));
                else motion(x-prevX,y-prevY);
                prevX=x; prevY=y; return true;
            }
            if(action == MotionEvent.ACTION_UP) {
                if(!moved && System.currentTimeMillis()-downAt < 450) click(1);
                return true;
            }
            return true;
        });
        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); root.addView(actions);
        Button left=button("Clic sinistro"); left.setOnClickListener(v -> click(1)); actions.addView(left,new LinearLayout.LayoutParams(0,-2,1));
        Button right=button("Clic destro"); right.setOnClickListener(v -> click(2)); actions.addView(right,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout scrollBtns = new LinearLayout(this); scrollBtns.setOrientation(LinearLayout.HORIZONTAL); root.addView(scrollBtns);
        Button up=button("Scorri ↑"); up.setOnClickListener(v -> wheel(5)); scrollBtns.addView(up,new LinearLayout.LayoutParams(0,-2,1));
        Button down=button("Scorri ↓"); down.setOnClickListener(v -> wheel(-5)); scrollBtns.addView(down,new LinearLayout.LayoutParams(0,-2,1));
        addHint(root,"L'app deve restare aperta. Compatibilità dipendente dal telefono e dal modello Fire Stick. Nessun servizio o root richiesto.");
    }
    @Override protected void onDestroy() {
        if(hid != null && permission()) { try { hid.unregisterApp(); adapter.closeProfileProxy(BluetoothProfile.HID_DEVICE,hid); } catch(Exception ignored) {} }
        super.onDestroy();
    }
}
