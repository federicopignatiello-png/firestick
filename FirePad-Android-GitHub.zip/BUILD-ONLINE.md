# Scaricare l'APK FirePad

La repository `federicopignatiello-png/firestick` include il workflow GitHub Actions che compila l'app.

1. Apri la scheda **Actions** della repository.
2. Seleziona **Build FirePad APK** e apri l'esecuzione più recente completata con successo.
3. In fondo alla pagina, scarica l'artefatto **FirePad-debug-APK**.
4. Estrai lo ZIP: contiene `app-debug.apk`.
5. Trasferisci l'APK sul telefono Android e aprilo per installare FirePad.

L'APK è una build di debug. Il progetto è un prototipo: la compatibilità Bluetooth HID dipende dal telefono e dalla Fire TV.
