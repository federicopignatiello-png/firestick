# FirePad / 01 — Android Bluetooth HID mouse

Prototipo nativo **Android 9+ (API 28)**. Simula un mouse via **Bluetooth HID classico**, non BLE GATT. Nessuna app necessaria sulla Fire TV.

## Aprire e compilare
1. Installa Android Studio sul Mac.
2. `Open` → seleziona questa cartella `firepad-android`.
3. Consenti la sincronizzazione Gradle (richiede accesso a Internet per scaricare Gradle/Android Gradle Plugin e Android SDK 35, se non presenti).
4. Collega un telefono Android via USB, attiva debug USB e premi **Run**, oppure `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
5. APK debug: `app/build/outputs/apk/debug/app-debug.apk`.

## Test
1. Apri le impostazioni Bluetooth della Fire Stick e aggiungi un dispositivo Bluetooth.
2. Sul telefono, esegui FirePad, concedi il permesso Bluetooth e mantieni l'app aperta.
3. Abbina il telefono alla Fire Stick tramite le rispettive impostazioni Bluetooth. L'abbinamento è legato al modello: se la Fire Stick non vede il telefono oppure non consente l'associazione, non c'è garanzia che questa via funzioni.
4. Torna a FirePad, premi **Riprova / aggiorna dispositivi**, seleziona la Fire Stick tra i dispositivi associati e attendi `Connesso`.
5. In Brave testa spostamento, tap, clic destro e scroll.

## Limiti importanti
- Alcuni Android non implementano il ruolo HID Device o rifiutano l'avvio del profilo; non è risolvibile con un semplice permesso.
- `BluetoothHidDevice.registerApp` può essere automaticamente disattivato se l'app lascia il primo piano.
- L'host Fire TV deve accettare mouse HID Bluetooth *classico* e consentire pairing; il fatto che supporti BLE non prova questa compatibilità.
- Il cursore potrebbe comunque non comparire in Brave, anche se la connessione riesce.
- Il prototipo non è stato compilato in questo ambiente e non è ancora stato testato su telefono/Fire Stick reali.
- Per motivi di semplicità include solo mouse, non tasti Home/Back del telecomando.

## Specifiche
Java 17 · Android Gradle Plugin 8.7.3 · compileSdk 35 · minSdk 28. API di sistema `BluetoothHidDevice`, report HID 4 byte (buttons, dx, dy, wheel), ID 1.
